var config = {
   
    paths: {
         "magebees/mvowlcarousel" : "Magebees_Mostviewed/js/owl.carousel.min",
         "magebeesMostviewed": "Magebees_Mostviewed/js/magebeesMostviewed"
    },
     shim: {
        'magebees/mvowlcarousel': {
            deps: ['jquery']
        },}
};





